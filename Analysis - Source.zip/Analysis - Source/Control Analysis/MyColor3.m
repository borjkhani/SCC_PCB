% MyColor

P1(1).LineWidth = 4;
P2(1).LineWidth = 4;
P3(1).LineWidth = 4;
P4(1).LineWidth = 4;
P5(1).LineWidth = 4;
P6(1).LineWidth = 4;
P7(1).LineWidth = 4;
P8(1).LineWidth = 4;
%P9(1).LineWidth = 4;


P1(1).Color= [1*rand, 1*rand, 1*rand]; %  Control
% P2(1).Color= [0.3010, 0.7450, 0.9330] % 6 
% P3(1).Color= [0.4940, 0.1840, 0.5560] % 12  
% P4(1).Color= [0.4660, 0.6740, 0.1880] % 18
% P5(1).Color= [0.9290, 0.6940, 0.1250]; % 25
% P6(1).Color= [0.6300, 0.41, 0.0980]; % 50
% P7(1).Color= [0.8350, 0.21, 0.2840] % 75
% P8(1).Color= [0.95, 0.05, 0.05] % 100