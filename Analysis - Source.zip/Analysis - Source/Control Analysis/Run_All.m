clc;
clear;
close all;

run Load.m

%%

% run Analysis1.m
% run Analysis2.m
% run Analysis2_ALL_PVs_PYRs_Sst_VIP.m
% run Analysis3_each_cell.m

run F_Analysis_All_CGP 
%%

%run All_Cells_PV_Mod_OneByOne_HWHH_Fast.m
run F_All_Cells_PV_Mod_OneByOne_HWHH_Fast.m


%%

%run HWHH_Analysis_Four.m
run F_HWHH_Analysis_Four.m

%%
% All_Cells_In_One_Plot_Normalized.m
% All_Cells_In_One_Plot_Fitting.m