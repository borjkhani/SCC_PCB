clear;
clc;
close all;

% No plots
run All_Cells_Sst_Mod_OneByOne_HWHH_Fast.m
%%
run Main_FR_Analysis.m

%%
% run Correlation_Analysis.m