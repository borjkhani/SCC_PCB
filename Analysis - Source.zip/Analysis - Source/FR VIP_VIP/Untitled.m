clc;
clear;
%Delta=NaN;

Mean_Ini= 3.5
Mean_F= 0.03
Up=83.75
Low=80

Delta=((Mean_F-Mean_Ini)/(Mean_Ini))*100
Mean_F
SEM=0.75*(Up-Low)


