clear;
clc;
close all;

% No plots
 run All_Cells_PV_Mod_OneByOne_HWHH_Fast.m


%%
% run Main_HWHH_Analysis.m
% 
% %%
% run Correlation_Analysis.m

%%
run Main_FR_Analysis.m