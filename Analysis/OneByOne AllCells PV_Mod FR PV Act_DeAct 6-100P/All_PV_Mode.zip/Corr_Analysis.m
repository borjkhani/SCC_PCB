clc

[R_RR,R_PValue] = corrplot(Med)