clear;
clc;
close all;

% No plots
run All_Cells_VIP_Mod_OneByOne_HWHH_Fast_Act_DeAct

%%
run Main_FR_Analysis.m

%
%run Correlation_Analysis.m

